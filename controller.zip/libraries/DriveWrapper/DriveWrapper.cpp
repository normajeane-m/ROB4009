#include "DriveWrapper.h"

#define P_MIN -10.0f
#define P_MAX 10.0f
#define V_MIN -20.0f
#define V_MAX 20.0f
#define T_MIN -3.6f
#define T_MAX 3.6f

#define KP_MIN 0.0f
#define KP_MAX 500.0f

#define KD_MIN 0.0f
#define KD_MAX 5.0f

#define ERROR_OVER_VOLT 0x08
#define ERROR_UNDER_VOLT 0x09
#define ERROR_OVER_CUR 0x0A
#define ERROR_HEAT_CHIP 0x0B
#define ERROR_HEAT_COIL 0x0C
#define ERROR_COM_FAIL 0x0D
#define ERROR_OVER_COMP 0x0E // 과부하

#define COMM_DELAY_US 10

float uint2float(int x_int, float x_min, float x_max, int bits)
{
  float span = x_max - x_min;
  float offset = x_min;
  return ((float)x_int) * span / ((float)((1 << bits) - 1)) + offset;
}

int float2uint(float x, float x_min, float x_max, int bits)
{
  float span = x_max - x_min;
  float offset = x_min;
  return (int)((x - offset) * ((float)((1 << bits) - 1)) / span);
}

DriveWrapper::DriveWrapper()
    : cmd_msg({CanMsg(CanStandardId(0x01), 8, nullptr),
               CanMsg(CanStandardId(0x02), 8, nullptr)})
{
  buildCommandMessage(0, 0, 0, cmd_msg[0].data);
  buildCommandMessage(0, 0, 0, cmd_msg[1].data);
}

void DriveWrapper::setTorque(uint32_t node_id, float torque)
{
  torque = constrain(torque, T_MIN, T_MAX);

  uint16_t t_encoded = float2uint(torque, T_MIN, T_MAX, 12);
  cmd_msg[node_id - 1].data[6] = (cmd_msg[node_id - 1].data[6] & 0xF0) | (t_encoded >> 8);
  cmd_msg[node_id - 1].data[7] = t_encoded & 0xFF;

  sendMessage(cmd_msg[node_id - 1]);
}

FDriveState &DriveWrapper::getState(uint32_t node_id)
{
  return states[node_id - 1];
}

void DriveWrapper::enable(uint32_t node_id)
{
  if (locked_)
  {
    return;
  }
  sendPresetCommand(node_id, EPresetCommand::Start);
  enabled[node_id - 1] = true;
}

void DriveWrapper::disable(uint32_t node_id)
{
  setTorque(node_id, 0.0f);
  sendPresetCommand(node_id, EPresetCommand::Stop);
  enabled[node_id - 1] = false;
}

void DriveWrapper::reset(uint32_t node_id)
{
  sendPresetCommand(node_id, EPresetCommand::Reset);
}

void DriveWrapper::buildCommandMessage(float pos, float vel, float torque, uint8_t buff[8])
{
  uint16_t p_encoded = float2uint(pos, P_MIN, P_MAX, 16);
  uint16_t v_encoded = float2uint(vel, V_MIN, V_MAX, 12);
  uint16_t t_encoded = float2uint(torque, T_MIN, T_MAX, 12);
  uint16_t kp_encoded = float2uint(0.0f, KP_MIN, KP_MAX, 12);
  uint16_t kd_encoded = float2uint(0.0f, KD_MIN, KD_MAX, 12);

  buff[0] = p_encoded >> 8;
  buff[1] = p_encoded;
  buff[2] = (v_encoded >> 4) & 0xFF;
  buff[3] = ((v_encoded & 0x0F) << 4) | (kp_encoded >> 8);
  buff[4] = kp_encoded & 0xFF;
  buff[5] = (kd_encoded >> 4) & 0xFF;
  buff[6] = ((kd_encoded & 0x0F) << 4) | (t_encoded >> 8);
  buff[7] = t_encoded & 0xFF;
}

void DriveWrapper::decodeMessage(const uint8_t buff[8])
{
  uint8_t node_id = buff[0] & 0x0F;

  states[node_id - 1].err_code = buff[0] >> 4;
  states[node_id - 1].temp_chip = buff[6];
  states[node_id - 1].temp_rotor = buff[7];

  uint16_t p_encoded = (buff[1] << 8) | buff[2];
  uint16_t v_encoded = (buff[3] << 4) | (buff[4] >> 4);
  uint16_t t_encoded = ((buff[4] & 0x0F) << 8) | buff[5];

  states[node_id - 1].pos = uint2float(p_encoded, P_MIN, P_MAX, 16);
  states[node_id - 1].vel = uint2float(v_encoded, V_MIN, V_MAX, 12);
  states[node_id - 1].torque = uint2float(t_encoded, T_MIN, T_MAX, 12);

  if (states[node_id - 1].err_code >= 8)
  {
    Serial.print(node_id);
    Serial.print("]");
    Serial.print("ERR: ");
    Serial.println(states[node_id - 1].err_code);
  }
}

void DriveWrapper::sendMessage(CanMsg &msg)
{
  while (true)
  {
    if (CAN.write(msg) == 1)
    {
      break;
    }

    delayMicroseconds(COMM_DELAY_US);
  }
}

void DriveWrapper::sendPresetCommand(uint32_t node_id, EPresetCommand command)
{
  uint8_t cmd;
  switch (command)
  {
  case EPresetCommand::Start:
    cmd = 0xFC;
    break;
  case EPresetCommand::Stop:
    cmd = 0xFD;
    break;
  case EPresetCommand::Reset:
    cmd = 0xFE;
    break;
  default:
    cmd = 0xFD;
    break;
  }

  uint8_t data[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, cmd};
  CanMsg const msg(CanStandardId(node_id), sizeof(data), data);

  while (true)
  {
    if (CAN.write(msg) == 1)
    {
      break;
    }

    delayMicroseconds(COMM_DELAY_US);
  }
}

void DriveWrapper::recvMessage()
{
  while (CAN.available())
  {
    CanMsg const msg = CAN.read();
    decodeMessage(msg.data);
  }
}