#pragma once

#include <Arduino_CAN.h>
#include <math.h>

#ifndef VEL_TH
#define VEL_TH 3.14f
#endif

enum EPresetCommand
{
  Start,
  Stop,
  Reset
};

struct FDriveState
{
  uint8_t err_code = 0;
  float pos = 0;
  float vel = 0;
  float torque = 0;

  uint8_t temp_chip = 0;
  uint8_t temp_rotor = 0;
};

class DriveWrapper
{
public:
  explicit DriveWrapper();

  void setTorque(uint32_t node_id, float torque);
  FDriveState &getState(uint32_t node_id);

  void enable(uint32_t node_id);
  void disable(uint32_t node_id);
  void reset(uint32_t node_id);

  bool is_running(uint32_t node_id)
  {
    return enabled[node_id - 1];
  }

  void update()
  {
    recvMessage();
    if ((abs(states[0].vel) > VEL_TH) || (abs(states[1].vel) > VEL_TH))
    {
      disable(0x01);
      disable(0x02);

      locked_ = true;
    }
  }

  bool locked() { return locked_; }

private:
  void buildCommandMessage(float pos, float vel, float torque, uint8_t buff[8]);
  void decodeMessage(const uint8_t buff[8]);

  void sendMessage(CanMsg &msg);
  void sendPresetCommand(uint32_t node_id, EPresetCommand command);
  void recvMessage();

private:
  CanMsg cmd_msg[2];
  FDriveState states[2];
  bool enabled[2] = {false, false};

  bool locked_ = false;
};