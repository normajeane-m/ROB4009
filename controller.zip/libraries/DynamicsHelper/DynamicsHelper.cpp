#include "Arduino.h"
#include "DynamicsHelper.h"

void DynamicsHelper::computeM(Mat &mat)
{
  Mat jac_c1 = computeJacCom1();
  Mat jac_c2 = computeJacCom2();

  mat = (~jac_c1) * jac_c1 * m1_;
  mat += Mat((~jac_c2) * jac_c2 * m2_);
  mat += Mat({i1_ + i2_, i2_, i2_, i2_});
}

void DynamicsHelper::computeC(Mat &mat)
{
  float h = computeH();

  mat(0, 0) = h * v2_;
  mat(0, 1) = h * (v1_ + v2_);
  mat(1, 0) = -h * v1_;
  mat(1, 1) = 0;
}

void DynamicsHelper::computeG(Vec &vec)
{
  vec(0, 0) = ((m1_ * lc1_ + m2_ * l1_) * cos(q1_) + m2_ * lc2_ * cos(q1_ + q2_)) * G_ACC;
  vec(1, 0) = (m2_ * lc2_ * cos(q1_ + q2_)) * G_ACC;
}

float DynamicsHelper::computeH()
{
  return -m2_ * l1_ * lc2_ * sin(q2_);
}

Mat DynamicsHelper::computeJacCom1()
{
  Mat jac = {0, 0, 0, 0};
  jac(0, 0) = -lc1_ * sin(q1_);
  jac(1, 0) = lc1_ * cos(q1_);

  return jac;
}

Mat DynamicsHelper::computeJacCom2()
{
  Mat jac = {0, 0, 0, 0};
  jac(0, 0) = -l1_ * sin(q1_) - lc2_ * sin(q1_ + q2_);
  jac(0, 1) = -lc2_ * sin(q1_ + q2_);
  jac(1, 0) = l1_ * cos(q1_) + lc2_ * cos(q1_ + q2_);
  jac(1, 1) = lc2_ * cos(q1_ + q2_);

  return jac;
}

void DynamicsHelper::computePosTool(Vec &vec)
{
  vec(0, 0) = l1_ * cos(q1_) + l2_ * cos(q1_ + q2_);
  vec(1, 0) = l1_ * sin(q1_) + l2_ * sin(q1_ + q2_);
}

void DynamicsHelper::computeJacTool(Mat &mat)
{
  mat(0, 0) = -l1_ * sin(q1_) - l2_ * sin(q1_ + q2_);
  mat(0, 1) = -l2_ * sin(q1_ + q2_);
  mat(1, 0) = l1_ * cos(q1_) + l2_ * cos(q1_ + q2_);
  mat(1, 1) = l2_ * cos(q1_ + q2_);
}

void DynamicsHelper::computeJacDiffTool(Mat &mat)
{
  mat(0, 0) = -l1_ * cos(q1_) * v1_ - l2_ * cos(q1_ + q2_) * (v1_ + v2_);
  mat(0, 1) = -l2_ * cos(q1_ + q2_) * (v1_ + v2_);
  mat(1, 0) = -l1_ * sin(q1_) * v1_ - l2_ * cos(q1_ + q2_) * (v1_ + v2_);
  mat(1, 1) = -l2_ * sin(q1_ + q2_) * (v1_ + v2_);
}

//     djac[0][1] = -self.l2 * np.cos(self.q1 + self.q2) * (self.v1 + self.v2)
//     djac[1][0] = -self.l1 * np.sin(self.q1) * self.v1 - self.l2 * np.cos(
//         self.q1 + self.q2
//     ) * (self.v1 + self.v2)
//     djac[1][1] = -self.l2 * np.sin(self.q1 + self.q2) * (self.v1 + self.v2)

//     return djac
