#pragma once

#include <math.h>
#include <BasicLinearAlgebra.h>
#include "DriveWrapper.h"

using namespace BLA;

#define G_ACC 0 // 9.80665
#define M1 0.89642
#define M2 0.21547
#define M3 0.389//0.20421 
#define L1 0.143
#define L2 0.102
#define LC1 93.27e-3
#define LC2 20.67e-3
#define LC3 L2

#define I1 3907105.16e-9
#define I2 343801.41e-9
#define I3 59128.57e-9//23564.075e-6//59128.57e-9 <<- 펜들럼system mass추가

const float M23 = M2 + M3;
const float LC23 = (LC2 * M2 + L2 * M3) / M23;
const float I23 = I2 + M2 * (LC2 - LC23) * (LC2 - LC23) + I3 + M3 * (L2 - LC23) * (L2 - LC23);
//^평행축정리 eq..

typedef BLA::Matrix<2, 2> Mat;
typedef BLA::Matrix<2, 1> Vec;

class DynamicsHelper
{
public:
  DynamicsHelper(float m1 = M1, float m2 = M23, float l1 = L1, float l2 = L2, float lc1 = LC1, float lc2 = LC23, float i1 = I1, float i2 = I23) : m1_(m1), m2_(m2), l1_(l1), l2_(l2), lc1_(lc1), lc2_(lc2), i1_(i1), i2_(i2)
  {
    q1_ = -M_PI / 2;
    q2_ = 0.0f;
    v1_ = 0.0f;
    v2_ = 0.0f;
  }

  void computeM(Mat &mat);
  void computeC(Mat &mat);
  void computeG(Vec &vec);

  Mat computeJacCom1();
  Mat computeJacCom2();

  void update(float q1, float q2, float v1, float v2)
  {
    q1_ = q1;
    q2_ = q2;
    v1_ = v1;
    v2_ = v2;
  }

  void update(FDriveState &state1, FDriveState &state2)
  {
    q1_ = state1.pos;
    v1_ = state1.vel;

    q2_ = state2.pos;
    v2_ = state2.vel;
  }

  void computePosTool(Vec &vec);
  void computeJacTool(Mat &mat);
  void computeJacDiffTool(Mat &mat);

private:
  float computeH();

  float q1_;
  float q2_;
  float v1_;
  float v2_;

  const float m1_;
  const float m2_;
  const float l1_;
  const float l2_;
  const float lc1_;
  const float lc2_;
  const float i1_;
  const float i2_;
};