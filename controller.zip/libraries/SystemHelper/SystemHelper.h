#pragma once

#include <Arduino.h>
#include <Arduino_CAN.h>

#include "TimerWrapper.h"
#include "DriveWrapper.h"

#define SW_PIN 3
#define RELAY_PIN 6
#define M1_BRAKE_PIN 7
#define M2_BRAKE_PIN 8
#define BUZZER_PIN 9

#ifndef DEBOUNCE_INTERVAL_MS
#define DEBOUNCE_INTERVAL_MS 500
#endif

void onButtonClicked();
void onTimerCalled();

uint32_t start_time = 0;

void tick()
{
  start_time = millis();
}

uint32_t tock()
{
  return millis() - start_time;
}

TimerWrapper *getTimerInstance()
{
  static TimerWrapper timer;
  return &timer;
}

void buttonCallback()
{
  static unsigned long triggered = 0;
  if (millis() - triggered < DEBOUNCE_INTERVAL_MS)
  {
    return;
  }
  triggered = millis();

  onButtonClicked();
}

void timerCallback(timer_callback_args_t *args)
{
  onTimerCalled();
}

void initializeSystem(float freq_hz = 1)
{
  pinMode(SW_PIN, INPUT_PULLUP);
  pinMode(RELAY_PIN, OUTPUT);
  
  pinMode(M1_BRAKE_PIN, OUTPUT);
  pinMode(M2_BRAKE_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(RELAY_PIN, 0);
  digitalWrite(M1_BRAKE_PIN, 0);
  digitalWrite(M2_BRAKE_PIN, 0);

  Serial.begin(9600);
  // while (!Serial)
  // {
  // }

  if (!CAN.begin(CanBitRate::BR_1000k))
  {
    Serial.println("CAN.begin() 실패");
    while (true)
    {
    }
  }

  attachInterrupt(digitalPinToInterrupt(SW_PIN), buttonCallback, FALLING);

  auto timer = getTimerInstance()->init(timerCallback, freq_hz);
}

bool startTimer()
{
  auto timer = getTimerInstance();
  if (!timer->is_running())
  {
    return timer->start();
  }
  return true;
}

bool stopTimer()
{
  auto timer = getTimerInstance();
  if (timer->is_running())
  {
    return timer->stop();
  }
  return true;
}

void unlock()
{
  digitalWrite(RELAY_PIN, 1);
  // Serial.println("RELAY_PIN");
  // delay(1500);
  // digitalWrite(M1_BRAKE_PIN, 1);
  // Serial.println("M1_BRAKE_PIN");
  // delay(1500);
  digitalWrite(M2_BRAKE_PIN, 1);
  Serial.println("M2_BRAKE_PIN");
  delay(1500);
}

void lock()
{
  digitalWrite(RELAY_PIN, 0);
  digitalWrite(M1_BRAKE_PIN, 0);
  digitalWrite(M2_BRAKE_PIN, 0);
}

void playBuzzer(unsigned int freq = 500, unsigned int num_repeat = 1)
{
  for (int i = 0; i < num_repeat; i++)
  {
    tone(BUZZER_PIN, freq);
    delay(200);
    noTone(BUZZER_PIN);
    delay(100);
  }
}