#include "TimerWrapper.h"

bool TimerWrapper::init(void (*callback_fn)(timer_callback_args_t *args), float freq_hz)
{
  uint8_t timer_type = GPT_TIMER;
  int8_t timer_index = FspTimer::get_available_timer(timer_type);
  if (timer_index < 0)
  {
    timer_index = FspTimer::get_available_timer(timer_type, true);
  }
  if (timer_index < 0)
  {
    Serial.println("Can't find available timer");
    return false;
  }

  FspTimer::force_use_of_pwm_reserved_timer();

  if (!timer_.begin(TIMER_MODE_PERIODIC, timer_type, timer_index, freq_hz, 0.0f, callback_fn))
  {
    Serial.println("Can't start timer");
    return false;
  }

  if (!timer_.setup_overflow_irq())
  {
    return false;
  }

  if (!timer_.open())
  {
    return false;
  }

  return true;
}

bool TimerWrapper::start()
{
  bool success = timer_.start();
  if (success)
  {
    enabled_ = true;
  }
  return success;
}

bool TimerWrapper::stop()
{
  bool success = timer_.stop();
  if (success)
  {
    enabled_ = false;
  }
  return success;
}