#pragma once

#include "Fsptimer.h"

class TimerWrapper
{
public:
  bool init(void (*callback_fn)(timer_callback_args_t *args) = nullptr, float freq_hz = 1000.0f);
  bool start();
  bool stop();

  bool is_running()
  {
    return enabled_;
  }

private:
  FspTimer timer_;
  bool enabled_ = false;
};