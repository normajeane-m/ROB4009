#!/usr/bin/env python3
"""
시리얼 통신 모듈
Arduino와의 통신을 담당합니다.
"""

import serial
import serial.tools.list_ports
import struct
import threading
import time
from typing import Optional, Dict

# ===============================
# [ 시리얼 통신 설정 ]
# ===============================
PACK_FMT = "<8f"  # little-endian, 8 floats
PACK_SIZE = struct.calcsize(PACK_FMT)

# ===============================
# [ 통신 속도 측정 ]
# ===============================
MAX_RX_TIMES = 20  # 최근 20개 데이터로 평균 계산


class SerialComm:
    """시리얼 통신 클래스"""
    
    def __init__(self):
        self.serial_port: Optional[serial.Serial] = None
        self.running = False
        self.data_lock = threading.Lock()
        self.send_lock = threading.Lock()
        
        # Arduino에서 받은 데이터
        self.current_data = {
            'x': 0.0,      # Cartesian x
            'y': 0.0,      # Cartesian y
            'xdot': 0.0,   # Cartesian x velocity
            'ydot': 0.0,   # Cartesian y velocity
            'q1': 0.0,     # Joint 1 angle (rad)
            'q2': 0.0,     # Joint 2 angle (rad)
            'q1dot': 0.0,  # Joint 1 velocity
            'q2dot': 0.0   # Joint 2 velocity
        }
        
        # 통신 속도 측정
        self.comm_rate = 0.0  # Hz
        self.last_rx_time = 0.0
        self.rx_times = []  # 최근 수신 시간들 (이동 평균 계산용)
        
        self.read_thread: Optional[threading.Thread] = None
    
    def connect(self, port_name: str, baudrate: int = 9600) -> bool:
        """시리얼 포트 연결"""
        try:
            self.serial_port = serial.Serial(port_name, baudrate, timeout=0.1, write_timeout=0.1)
            self.serial_port.reset_input_buffer()  # 입력 버퍼 초기화
            self.serial_port.reset_output_buffer()  # 출력 버퍼 초기화
            time.sleep(2)  # 안정화 대기
            print("Connected!")
            return True
        except Exception as e:
            print(f"Connection failed: {e}")
            return False
    
    def disconnect(self):
        """시리얼 포트 연결 해제"""
        self.running = False
        if self.read_thread:
            self.read_thread.join(timeout=1.0)
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
    
    def start_read_thread(self):
        """시리얼 수신 스레드 시작"""
        if not self.serial_port or not self.serial_port.is_open:
            return False
        
        self.running = True
        self.read_thread = threading.Thread(target=self._serial_read_thread, daemon=True)
        self.read_thread.start()
        return True
    
    def send_joint_command(self, q1: float, q2: float) -> bool:
        """Arduino에 joint control 명령 전송"""
        if not (self.serial_port and self.serial_port.is_open):
            return False
        
        try:
            # Joint 모드: [0, 0, 0, 0, q1, q2, 0, 0]
            vals = [0.0, 0.0, 0.0, 0.0, q1, q2, 0.0, 0.0]
            packet = b"f" + struct.pack(PACK_FMT, *vals)
            print(f"[JOINT] Sending: vals={vals}")
            with self.send_lock:
                self.serial_port.write(packet)
                self.serial_port.flush()  # 버퍼 즉시 전송
            return True
        except Exception as e:
            print(f"Send error: {e}")
            return False
    
    def send_cartesian_command(self, x: float, y: float, xdot: float = 0.0, ydot: float = 0.0) -> bool:
        """Arduino에 Cartesian control 명령 전송"""
        if not (self.serial_port and self.serial_port.is_open):
            return False
        
        try:
            # Cartesian 모드: [x, y, xdot, ydot, 0, 0, 0, 0]
            vals = [x, y, xdot, ydot, 0.0, 0.0, 0.0, 0.0]
            packet = b"f" + struct.pack(PACK_FMT, *vals)
            print(f"[CARTESIAN] Sending: vals={vals}")
            with self.send_lock:
                self.serial_port.write(packet)
                self.serial_port.flush()  # 버퍼 즉시 전송
            return True
        except Exception as e:
            print(f"Send error: {e}")
            return False
    
    def get_data(self) -> Dict[str, float]:
        """현재 데이터 복사본 반환 (스레드 안전)"""
        with self.data_lock:
            return self.current_data.copy()
    
    def get_comm_rate(self) -> float:
        """통신 속도 반환 (Hz)"""
        return self.comm_rate
    
    def _serial_read_thread(self):
        """시리얼 수신 스레드"""
        buffer = bytearray()
        data_count = 0
        
        while self.running:
            if self.serial_port and self.serial_port.is_open:
                try:
                    # 사용 가능한 데이터 읽기
                    if self.serial_port.in_waiting > 0:
                        buffer.extend(self.serial_port.read(self.serial_port.in_waiting))
                        
                        # 버퍼에서 완전한 패킷 찾기
                        while len(buffer) >= PACK_SIZE:
                            # float 배열 데이터 읽기 (Arduino는 'f' 없이 바로 보냄)
                            data = bytes(buffer[:PACK_SIZE])
                            buffer = buffer[PACK_SIZE:]
                            
                            try:
                                vals = struct.unpack(PACK_FMT, data)
                                
                                # 통신 속도 측정
                                current_time = time.time()
                                if self.last_rx_time > 0:
                                    dt = current_time - self.last_rx_time
                                    if dt > 0:
                                        self.rx_times.append(dt)
                                        if len(self.rx_times) > MAX_RX_TIMES:
                                            self.rx_times.pop(0)
                                        
                                        # 평균 간격으로 주파수 계산
                                        if len(self.rx_times) > 1:
                                            avg_interval = sum(self.rx_times) / len(self.rx_times)
                                            self.comm_rate = 1.0 / avg_interval if avg_interval > 0 else 0.0
                                
                                self.last_rx_time = current_time
                                
                                with self.data_lock:
                                    self.current_data['x'] = vals[0]
                                    self.current_data['y'] = vals[1]
                                    self.current_data['xdot'] = vals[2]
                                    self.current_data['ydot'] = vals[3]
                                    self.current_data['q1'] = vals[4]
                                    self.current_data['q2'] = vals[5]
                                    self.current_data['q1dot'] = vals[6]
                                    self.current_data['q2dot'] = vals[7]
                                
                                data_count += 1
                            except struct.error as e:
                                print(f"Unpack error: {e}")
                                # 잘못된 데이터이므로 버퍼 초기화
                                buffer = bytearray()
                                break
                    else:
                        time.sleep(0.001)  # 짧은 대기
                except Exception as e:
                    print(f"Serial read error: {e}")
                    time.sleep(0.01)
            else:
                time.sleep(0.1)


def list_serial_ports():
    """사용 가능한 시리얼 포트 목록 반환"""
    ports = serial.tools.list_ports.comports()
    return ports

